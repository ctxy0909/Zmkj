package com.ruoyi.project.module.agent.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.framework.web.domain.BaseEntity;
import java.util.Date;

/**
 * 代理商表 zmkj_agent
 * 
 * @author ruoyi
 * @date 2019-01-07
 */
public class Agent extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 代理商id */
	private Integer id;
	/** 是否可以发展下级（Y.可以发展下级  N.不可发展下级） */
	private String devellopNextlevel;
	/** 父级代理商ID */
	private Integer parentAgentId;
	/** 代理商名称 */
	private $column.attrType agentName;
	/** 联系电话 */
	private $column.attrType phone;
	/** 联系地址 */
	private $column.attrType adress;
	/** 邮箱 */
	private $column.attrType email;
	/** 登录账号 */
	private String loginName;
	/** 密码 */
	private String password;
	/** 盐加密 */
	private String salt;
	/** 创建者 */
	private String createBy;
	/** 创建时间 */
	private Date createTime;
	/** 更新者 */
	private String updateBy;
	/** 更新时间 */
	private Date updateTime;
	/**  */
	private String remark;

	public void setId(Integer id) 
	{
		this.id = id;
	}

	public Integer getId() 
	{
		return id;
	}
	public void setDevellopNextlevel(String devellopNextlevel) 
	{
		this.devellopNextlevel = devellopNextlevel;
	}

	public String getDevellopNextlevel() 
	{
		return devellopNextlevel;
	}
	public void setParentAgentId(Integer parentAgentId) 
	{
		this.parentAgentId = parentAgentId;
	}

	public Integer getParentAgentId() 
	{
		return parentAgentId;
	}
	public void setAgentName($column.attrType agentName) 
	{
		this.agentName = agentName;
	}

	public $column.attrType getAgentName() 
	{
		return agentName;
	}
	public void setPhone($column.attrType phone) 
	{
		this.phone = phone;
	}

	public $column.attrType getPhone() 
	{
		return phone;
	}
	public void setAdress($column.attrType adress) 
	{
		this.adress = adress;
	}

	public $column.attrType getAdress() 
	{
		return adress;
	}
	public void setEmail($column.attrType email) 
	{
		this.email = email;
	}

	public $column.attrType getEmail() 
	{
		return email;
	}
	public void setLoginName(String loginName) 
	{
		this.loginName = loginName;
	}

	public String getLoginName() 
	{
		return loginName;
	}
	public void setPassword(String password) 
	{
		this.password = password;
	}

	public String getPassword() 
	{
		return password;
	}
	public void setSalt(String salt) 
	{
		this.salt = salt;
	}

	public String getSalt() 
	{
		return salt;
	}
	public void setCreateBy(String createBy) 
	{
		this.createBy = createBy;
	}

	public String getCreateBy() 
	{
		return createBy;
	}
	public void setCreateTime(Date createTime) 
	{
		this.createTime = createTime;
	}

	public Date getCreateTime() 
	{
		return createTime;
	}
	public void setUpdateBy(String updateBy) 
	{
		this.updateBy = updateBy;
	}

	public String getUpdateBy() 
	{
		return updateBy;
	}
	public void setUpdateTime(Date updateTime) 
	{
		this.updateTime = updateTime;
	}

	public Date getUpdateTime() 
	{
		return updateTime;
	}
	public void setRemark(String remark) 
	{
		this.remark = remark;
	}

	public String getRemark() 
	{
		return remark;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("devellopNextlevel", getDevellopNextlevel())
            .append("parentAgentId", getParentAgentId())
            .append("agentName", getAgentName())
            .append("phone", getPhone())
            .append("adress", getAdress())
            .append("email", getEmail())
            .append("loginName", getLoginName())
            .append("password", getPassword())
            .append("salt", getSalt())
            .append("createBy", getCreateBy())
            .append("createTime", getCreateTime())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .append("remark", getRemark())
            .toString();
    }
}
